<!DOCTYPE html>
<html>

<head>
	<link rel="stylesheet" type="text/css" href="css/style.css"> 
	<link rel="stylesheet" type="text/css" href="css/style2.css">
	<meta charset="utf-8">
	<title>
		The Baggins
	</title>
</head>
<body>
	<style rel="stylesheet">
		body{
			background-image: url("./imagens/fusca4.jpg");
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: 100%;
		}
	</style>
	<div>
		<div class="topnav">
			<ul>
				<li class="icon">
	   				 <a href="javascript:void(0);" onclick="myFunction()">☰</a>
	  			</li>
				<li><a href="#contact" title="">Contato</a></li>
				<li><a href="/forrestaurant/#" title="">Onde Estamos</a></li>
				<li><a href="quem_somos.php" target="_parent" title="">Quem Somos</a></li>
				<div>
					<a href="/home">
					<span class="span-logo">
					<!-- <img src="./static/image/fancy_monk_logo_final.png" /> -->
					<!-- <img src="./static/fancymonk_logo/ic_fancy_monk_white.png" /> -->
					<img  src="./imagens/home_w.png" >
					<!-- <p>Fancymonk</p> -->
					</span>
					</a>
				</div>
			</ul>
		</div>
		
		
	<section id="main">
	    <div class="fancy-monk">
	      <h1 style="text-shadow: 2px 2px #000000">The Baggins</h1> 
	      <div>
	         <div class="signinup">
	             <div>Não é Membro Ainda?</div>
	             <div>Cadastre-se agora!</div>
	             <div class="clearfix"></div>
	             <div>
	                 <input type="button" value="Cadastrar" class="btn btn-danger">
	                 <input type="button" value="Entrar" class="btn btn-danger" onclick="javascript:window.open('Login.php','_parent')">
	             </div>
	         </div> 
	      </div>
	    </div>
	 </section>	

</body>


</html>