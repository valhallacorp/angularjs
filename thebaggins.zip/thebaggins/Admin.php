<!DOCTYPE html>
<html>

<head>

	<link rel="stylesheet" type="text/css" href="css/style.css"> 
	<link rel="stylesheet" type="text/css" href="css/style2.css">
	<link rel="stylesheet" type="text/css" href="css/menu.css">
	<meta charset="utf-8">
	<title>
		The Baggins
	</title>
</head>
<body>
	<style rel="stylesheet">
		body{
			background-image: url("./imagens/fusca4.jpg");
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: 100%;
		}
	</style>
	<div>
		<div class="topnav">
			<ul>
				<li class="icon">
	   				 <a href="javascript:void(0);" onclick="myFunction()">☰</a>
	  			</li>
				<li><a href="contato.php" target="_parent" title="">Contato</a></li>
				<li><a href="onde_estamos.php" target="_parent" title="">Onde Estamos</a></li>
				<li><a href="quem_somos.php" target="_parent" title="">Quem Somos</a></li>
				<div>
					<a href="index.php" target="_parent">
					<span class="span-logo">
					
					<img style="margin: 5px; margin-left: 1px" src="./imagens/home_w.png" >

					</span>
					</a>
				</div>
			</ul>
		</div>
		
		
	<section id="main">
	    <div>
	      	<div>
	         	<div class="signinup" style="position: fixed;">
	             
	             	<div id="lateral">
	             		
		             		<div>
		             			<h3 class="link-titulo">MENU DE ADMINISTRAÇÃO</h3>
		             		</div>
	             		
						<div id="menu">
							
						    <ul class="box">					
						        <li><a href="profile.php" target="_parent" >Perfil</a></li>
						        <li><a href="Search.php" target="_parent">Procurar Oportunidades</a></li>
						        <li ><a href="#">Cadastrar Oportunidades</a></li>
						        <li ><a href="#">Configurações</a></li>
						    </ul>

							
						    
						<!-- mais seções -->

							</div> <!-- /#menu -->
							</div id="link"> <!-- vazio --> <div>
							</div> <!-- /#lateral -->

					</div> 
				</div>
			</div>
	</section>	

</body>


</html>