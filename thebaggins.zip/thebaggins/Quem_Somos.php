<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/style.css"> 
	<link rel="stylesheet" type="text/css" href="css/style2.css">	
	<title>
		The Baggins
	</title>
</head>
<body>
	<style rel="stylesheet">
		body{
			background-image: url("./imagens/fusca4.jpg");
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: 100%;
		}
	</style>
	<div>
		<div class="topnav">
			<ul>
				<li class="icon">
	   				 <a href="javascript:void(0);" onclick="myFunction()">☰</a>
	  			</li>
				<li><a href="contato.php" target="_parent"title="">Contato</a></li>
				<li><a href="onde_estamos.php" target="_parent" title="">Onde Estamos</a></li>
				<li><a href="quem_somos.php" target="_parent" title="">Quem Somos</a></li>
				<div>
					<a href="index.php" target="_parent">
					<span class="span-logo">
					
						<img style="margin: 5px; margin-left: 1px" src="./imagens/home_w.png"> 
					
					</span>
					</a>
				</div>
			</ul>
		</div>
		
		
	<section id="main">
	    <div class="fancy-monk">
	      <h1 style="text-shadow: 2px 2px #000000">The Baggins</h1> 
	      <div>
	         <div class="signinup" style="position: fixed;">
	             
	             <p  style="text-align: justify; margin:10px;">&nbsp;&nbsp;&nbsp;&nbsp;The Baggins é um projeto pioneiro em sua área, tem como objetivo intermediar o processo de busca e oferta de vagas de trabalho temporarias entre empresas e Viajantes/Mochileiros. <br>
	             &nbsp;&nbsp;&nbsp;&nbsp;The Baggins é uma plataforma web voltada para o maior conforto dos usuarios, onde, dentro de um unico lugar é possivel lançar e/ou buscar vagas de trabalho temporarias em diversas localidades.<br>
	             &nbsp;&nbsp;&nbsp;&nbsp;Com o The Baggins fica muito mais seguro trabalhar durante suas viagens, pois asseguramos que seu contrato seja firmado e fixado em nosso sistema, de maneira que o mesmo não podera ser alterado sem que seja registrado no sistema, evitando fraudes e lesões a qualquer uma das partes envolvidas.

	             </p>
	             

	         </div> 
	      </div>
	    </div>
	 </section>	

</body>


</html>