<!DOCTYPE html>
<html>

<head>

	<link rel="stylesheet" type="text/css" href="css/style.css"> 
	<link rel="stylesheet" type="text/css" href="css/style2.css">
	<link rel="stylesheet" type="text/css" href="css/menu.css">
	<link rel="stylesheet" type="text/css" href="css/timeline.css">
	<script type="text/javascript" scr="js/funcoes.js"></script>
	<meta charset="utf-8">

	<title>
		The Baggins
	</title>
</head>
<body>
	<style rel="stylesheet">
		body{
			background-image: url("./imagens/fusca4.jpg");
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: 100%;
		}
	</style>
	<div>
		<div class="topnav">
			<ul>
				<li class="icon">
	   				 <a href="javascript:void(0);" onclick="myFunction()">☰</a>
	  			</li>
		  			<form class="navbar-form navbar-left" role="search" style="margin-left: 40%">
				        <div class="form-group">
				          <input type="text" class="form-control" placeholder="Pesquisar">
				        </div>
				        <button type="button" class="btn btn-default" onclick="javascript:window.open('PainelVagas.php','_parent')">Pesquisar</button>
				    </form>
				<li><a href="contato.php" target="_parent" title="">Contato</a></li>
				<li><a href="onde_estamos.php" target="_parent" title="">Onde Estamos</a></li>
				<li><a href="quem_somos.php" target="_parent" title="">Quem Somos</a></li>
				<div>
					<a href="index.php" target="_parent">
					<span class="span-logo">
					
					<img src="./imagens/home_w.png" >

					</span>
					</a>
				</div>
			</ul>
		</div>
		
		
	<section id="main">
	    <div>
	      	<div>
	         	<div class="signinup" style="position: fixed;">
	             
	             	<div id="lateral">
	             		
		             		<div>
		             			<h3 class="link-titulo">MENU DE ADMINISTRAÇÃO</h3>
		             		</div>
	             		
						<div id="menu">
							
						    <ul class="box">					
						        <li><a href="profile.php" target="_parent" >Perfil</a></li>
						        <li><a href="search.php" target="_parent" >Procurar Oportunidades</a></li>
						        <li ><a href="#">Cadastrar Oportunidades</a></li>
						        <li ><a href="#">Configurações</a></li>
						    </ul>

							
						    
						<!-- mais seções -->

							</div> <!-- /#menu -->
							</div id="link"> <!-- vazio --> <div>
							</div> <!-- /#lateral -->

					</div> 

				</div>

			</div>

			

	</section>	
	<div class="page-header text-center" class="lateral">
			        <h1 id="timeline" style="margin-top: 60px; padding-top: 5px; margin-left: 18%">Painel de Vagas</h1>
			    </div>
			    <ul class="timeline">
			        <li>
			          <div class="timeline-badge primary"><a><i class="glyphicon glyphicon-record" rel="tooltip" title="Krabi - Tailandia" id=""></i></a></div>
			          <div class="timeline-panel">
			            <div class="timeline-heading">
			              <img class="img-responsive" src="./imagens/Krabi_tailandia.jpg" />
			              
			            </div>
			            <div class="timeline-body">
			            	<h3 class="titulo-vaga">Krabi - Tailandia</h3>
			              <p>Krabi - é uma cidade situada na costa oeste do sul da Tailândia, na foz do rio Krabi, que deságua na baia de Phangnga. Em 2005, tinha uma população de 24.986 abitantes. A cidade é a capital da província de Krabi, sendo o turismo uma indústria importante da cidade.<br><br>
			              Krabi é capital da província de mesmo nome, no sul da Tailândia, no litoral do Mar de Andamão, com talvez a mais antiga história do país. Muitas ferramentas de pedra, antigas imagens coloridas, miçangas, cerâmica e restos mortais encontrados em muitos penhascos e cavernas da província, indicam que Krabi tem sido o lar de Homo Sapiens desde o período 25.000 - 35.000 aC.</p>
			              
			            </div>
			            
			            <div class="timeline-footer">
			                <a><i class="glyphicon glyphicon-thumbs-up"></i></a>
			                <a><i class="glyphicon glyphicon-share"></i></a>
			                <a class="pull-right">Continuar Lendo</a>
			            </div>
			          </div>
			        </li>
			        
			        <li  class="timeline-inverted">
			          <div class="timeline-badge primary"><a><i class="glyphicon glyphicon-record invert" rel="tooltip" title="Montreal - Canada" id=""></i></a></div>
			          <div class="timeline-panel">
			            <div class="timeline-heading">
			              <img class="img-responsive" src="./imagens/montreal_canada.jpg" />
			              
			            </div>
			            <div class="timeline-body">
			            	<h3 class="titulo-vaga">Montreal - Canada</h3>
			              <p>Montreal (em francês: Montréal) é a maior cidade da província de Quebec e a segunda mais populosa do Canadá, além de ser uma das mais populosas cidades francófonas do mundo. É também uma região administrativa do Quebec. Situa-se na ilha homônima do Rio São Lourenço, sendo um dos principais centros industriais, comerciais e culturais da América do Norte.<br><br>
						  Montreal possui a segunda maior população francófona do mundo, depois de Paris. Porém, Montreal também possui uma considerável comunidade anglófona, e um crescente número de pessoas cujo idioma materno não é nem o francês nem o inglês.</p>
			             
			            </div>
			            
			            <div class="timeline-footer">
			                <a><i class="glyphicon glyphicon-thumbs-up"></i></a>
			                <a><i class="glyphicon glyphicon-share"></i></a>
			                <a class="pull-right">Continuar Lendo</a>
			            </div>
			          </div>
			        </li>
			        <li>
			          <div class="timeline-badge primary"><a><i class="glyphicon glyphicon-record" rel="tooltip" title="Hai - Africa" id=""></i></a></div>
			          <div class="timeline-panel">
			            <div class="timeline-heading">
			              <img class="img-responsive" src="./imagens/hai-africa.jpg" />
			              
			            </div>
			            <div class="timeline-body">
			            <h3 class="titulo-vaga">Hai Africa</h3>
			              <p>O Hai África fica em Kabiria, uma comunidade carente de Nairóbi, no Quênia. <br><br>
			              Venha Trabalhar como voluntariado no Hai Africa, Oferecemos comida e moradia.</p>
			              
			            </div>
			            
			            <div class="timeline-footer">
			                <a><i class="glyphicon glyphicon-thumbs-up"></i></a>
			                <a><i class="glyphicon glyphicon-share"></i></a>
			                <a class="pull-right">Continuar Lendo</a>
			            </div>
			          </div>
			        </li>
			        
			        <li  class="timeline-inverted">
			          <div class="timeline-badge primary"><a><i class="glyphicon glyphicon-record invert" rel="tooltip" title="Hilton hotel & Resort" id=""></i></a></div>
			          <div class="timeline-panel">
			          <div class="timeline-heading">
			              <img class="img-responsive" src="./imagens/hilton_hotel_and_resort.jpg" />
			              
			            </div>
			            <div class="timeline-body">
			            <h3 class="titulo-vaga">Hilton hotel & Resort</h3>
			              <p>O nome mais reconhecido do setor, a Hilton Hotels & Resorts destaca-se como líder global de estilo e inovação em hotelaria. Com mais de 92 anos de experiência, a Hilton continua sendo sinônimo de hotel pela abordagem inovadora em produtos, comodidades e serviço. Ajudamos a tornar mais fácil viajar com nosso design inteligente, conceitos inovadores de restaurante, hospitalidade autêntica e compromisso com a comunidade global. Hoje, a Hilton recebe hóspedes em mais países do que qualquer outra marca de hotel de serviço completo, com mais de 550 hotéis e resorts em 79 países e seis continentes</p>
			              
			            </div>
			            
			            <div class="timeline-footer">
			                <a><i class="glyphicon glyphicon-thumbs-up"></i></a>
			                <a><i class="glyphicon glyphicon-share"></i></a>
			                <a class="pull-right">Continuar Lendo</a>
			            </div>
			          </div>
			        </li>
			        <li>
			          <div class="timeline-badge primary"><a><i class="glyphicon glyphicon-record" rel="tooltip" title="Hilton hotel & Resort 2" id=""></i></a></div>
			          <div class="timeline-panel">
			            <div class="timeline-heading">
			              <img class="img-responsive" src="./imagens/hilton_hotel_and_resort2.jpg" />
			              
			            </div>
			            <div class="timeline-body">
			            <h3 class="titulo-vaga">Hilton hotel & Resort</h3>
			              <p>O nome mais reconhecido do setor, a Hilton Hotels & Resorts destaca-se como líder global de estilo e inovação em hotelaria. Com mais de 92 anos de experiência, a Hilton continua sendo sinônimo de hotel pela abordagem inovadora em produtos, comodidades e serviço. Ajudamos a tornar mais fácil viajar com nosso design inteligente, conceitos inovadores de restaurante, hospitalidade autêntica e compromisso com a comunidade global. Hoje, a Hilton recebe hóspedes em mais países do que qualquer outra marca de hotel de serviço completo, com mais de 550 hotéis e resorts em 79 países e seis continentes</p>
			              
			            </div>
			            
			            <div class="timeline-footer">
			                <a><i class="glyphicon glyphicon-thumbs-up"></i></a>
			                <a><i class="glyphicon glyphicon-share"></i></a>
			                <a class="pull-right">Continuar Lendo</a>
			            </div>
			          </div>
			        </li>
			        
			        <li  class="timeline-inverted">
			          <div class="timeline-badge primary"><a><i class="glyphicon glyphicon-record invert" rel="tooltip" title="London Eye Hostel" id=""></i></a></div>
			          <div class="timeline-panel">
			            <div class="timeline-heading">
			              <img class="img-responsive" src="./imagens/London-eye-hostel-londres.jpg" />
			              
			            </div>
			            <div class="timeline-body">
			            <h3 class="titulo-vaga">London Eye Hostel</h3>
			              <p>O London Eye Hostel é o lider em hospedagem na modalidade hostel. <br><br>
			              Localizado em diversas partes de londres, o London Eye Hostel oferece hospedagem para no maximo 25 pessoas bem acomodadas com todas as facilidades que um grande Hotel pode oferecer.<br><br>
			              Todos os quartos são equipados com Beliches para 9 pessoas, possui banheiro e cozinha compartilhados e uma linda sala de lazer, pensado de modo que todos os hospedes possam interagir e se conhecerem melhor.</p>
			              
			            </div>
			            
			            <div class="timeline-footer primary">
			                <a><i class="glyphicon glyphicon-thumbs-up"></i></a>
			                <a><i class="glyphicon glyphicon-share"></i></a>
			                <a class="pull-right">Continuar Lendo</a>
			            </div>
			          </div>
			        </li>

			        <li >
			          <div class="timeline-badge primary"><a><i class="glyphicon glyphicon-record invert" rel="tooltip" title="Genova - Italia" id=""></i></a></div>
			          <div class="timeline-panel">
			          <div class="timeline-heading">
			          	<img class="img-responsive" src="./imagens/genova-italia.jpeg">
			          </div>
			            <div class="timeline-body">
			            <h3 class="titulo-vaga">Genova - Italia</h3>
			              <p>Gênova é uma cidade e comuna italiana da região da Ligúria, Cidade metropolitana de Gênova, com cerca de 639.560 habitantes (1.510.000 na área metropolitana). Estende-se por uma área de 243 km², tendo uma densidade populacional de 2484 hab/km². Faz fronteira com Arenzano, Bargagli, Bogliasco, Bosio, Campomorone, Ceranesi, Davagna, Masone, Mele, Mignanego, Montoggio, Sant'Olcese, Sassello, Serra Riccò, Sori, Tiglieto, Urbe.<br><br>
			              Gênova é um importante porto marítimo que rivaliza com a cidade francesa de Marselha na disputa pelo lugar de melhor porto do mar Mediterrâneo e centro industrial cujo crescimento económico e internacionalização data dos séculos XII e XIV. É também capital da província de mesmo nome, e ocupa lugar de destaque no golfo de Gênova.</p>
			            </div>
			            
			            <div class="timeline-footer primary">
			                <a><i class="glyphicon glyphicon-thumbs-up"></i></a>
			                <a><i class="glyphicon glyphicon-share"></i></a>
			                <a class="pull-right">Continuar Lendo</a>
			            </div>
			          </div>
			        </li>
			        
			        <li class="clearfix" style="float: none;"></li>
			    </ul>


	

</body>


</html>