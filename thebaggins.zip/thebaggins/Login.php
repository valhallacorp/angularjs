<!DOCTYPE html>
<html>

<head>
	<link rel="stylesheet" type="text/css" href="css/style.css"> 
	<link rel="stylesheet" type="text/css" href="css/style2.css">
	<meta charset="utf-8">
	<title>
		The Baggins
	</title>
</head>
<body>
	<style rel="stylesheet">
		body{
			background-image: url("./imagens/fusca4.jpg");
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: 100%;
		}
	</style>
	<div>
		<div class="topnav">
			<ul>
				<li class="icon">
	   				 <a href="javascript:void(0);" onclick="myFunction()">☰</a>
	  			</li>
				<li><a href="contato.php" target="_parent" title="">Contato</a></li>
				<li><a href="onde_estamos.php" target="_parent"title="">Onde Estamos</a></li>
				<li><a href="quem_somos.php" target="_parent" title="">Quem Somos</a></li>
				<div>
					<a href="index.php" target="_parent">
					<span class="span-logo">
					
						<img style="margin: 5px; margin-left: 1px" src="./imagens/home_w.png"> 
					
					</span>
					</a>
				</div>
			</ul>
		</div>
		
		
	<section id="main">
	    <div class="fancy-monk">
	      <h1 style="text-shadow: 2px 2px #000000">The Baggins</h1> 
	      <div>
	         <div class="signinup" style="position: fixed;">
	             
	             <div class="container">
				    <div class="row">
				    	<div class="col-md-4 col-md-offset-4" style="margin-top: 5px;">
				    		<div class="panel panel-default">
							  	<div class="panel-heading">
							    	<h3 class="panel-title">Entrar via site</h3>
							 	</div>
							  	<div class="panel-body">
							    	<form accept-charset="UTF-8" role="form">
				                    <fieldset>
							    	  	<div class="form-group">
							    		    <input class="form-control" placeholder="seuemail@example.com" name="email" type="text">
							    		</div>
							    		<div class="form-group">
							    			<input class="form-control" placeholder="Senha" name="password" type="password" value="">
							    		</div>
							    		<div class="checkbox">
							    	    	<label>
							    	    		<input name="remember" type="checkbox" value="Remember Me"> Lembrar Login
							    	    	</label>
							    	    </div>
							    	</fieldset>
							      	</form>
							      	<input class="btn btn-lg btn-success btn-block" type="submit" value="Entrar" onclick="javascript:window.open('Admin.php','_parent')">
				                      <hr/>
				                    <center><h4>OU</h4></center>
				                    <input class="btn btn-lg btn-facebook btn-block" type="submit" value="Entrar via facebook" onclick="javascript:window.open('Admin.php','_parent')">

							    </div>
							</div>
						</div>
					</div>

	         </div> 
	      </div>
	    </div>
	 </section>	

</body>


</html>