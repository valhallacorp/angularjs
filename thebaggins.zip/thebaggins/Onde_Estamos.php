<!DOCTYPE html>
<html>

<head>
	<link rel="stylesheet" type="text/css" href="css/style.css"> 
	<link rel="stylesheet" type="text/css" href="css/style2.css">
	<meta charset="utf-8">
	<title>
		The Baggins
	</title>
</head>
<body>
	<style rel="stylesheet">
		body{
			background-image: url("./imagens/fusca4.jpg");
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: 100%;
		}
	</style>
	<div>
		<div class="topnav">
			<ul>
				<li class="icon">
	   				 <a href="javascript:void(0);" onclick="myFunction()">☰</a>
	  			</li>
				<li><a href="contato.php" target="_parent" title="">Contato</a></li>
				<li><a href="onde_estamos.php" target="_parent" title="">Onde Estamos</a></li>
				<li><a href="quem_somos.php" target="_parent" title="">Quem Somos</a></li>
				<div>
					<a href="index.php" target="_parent">
					<span class="span-logo">
					
						<img style="margin: 5px; margin-left: 1px" src="./imagens/home_w.png"> 
					
					</span>
					</a>
				</div>
			</ul>
		</div>
		
		
	<section id="main">
	    <div>

	      <div>
	         <div class="signinup" style="position: fixed; padding-top: 60px">
	             
	             <div class="map-responsive" style="margin: 1px">
   					<iframe src="https://www.google.com/maps/d/u/0/embed?mid=1staegW5xYW-0XicAu-4nDgM2uiI" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe>
				</div
	             

	         </div> 
	      </div>
	    </div>
	 </section>	

</body>


</html>