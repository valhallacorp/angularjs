<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="css/style.css"> 
    <link rel="stylesheet" type="text/css" href="css/style2.css">
    <meta charset="utf-8">
	<title>
		The Baggins
	</title>
</head>
<body>
	<style rel="stylesheet">
		body{
			background-image: url("./imagens/fusca4.jpg");
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: 100%;
		}
	</style>
	<div>
		<div class="topnav">
			<ul>
				<li class="icon">
	   				 <a href="javascript:void(0);" onclick="myFunction()">☰</a>
	  			</li>
				<li><a href="contato.php" target="_parent"title="">Contato</a></li>
				<li><a href="onde_estamos.php" target="_parent" title="">Onde Estamos</a></li>
				<li><a href="quem_somos.php" target="_parent" title="">Quem Somos</a></li>
				<div>
					<a href="index.php" target="_parent">
					<span class="span-logo">
					
						<img style="margin: 5px; margin-left: 1px" src="./imagens/home_w.png"> 
					
					</span>
					</a>
				</div>
			</ul>
		</div>
		
		
	<section id="main">
	    <div>

	      <div>
	         <div class="signinup" style="position: fixed;">
	             
	             <div class="jumbotron jumbotron-sm">
    <div >
        <div style="margin-top: 10px;">
            <div class="col-sm-12 col-lg-12" >
                <h1 class="h1" style="text-align: center; font-size: 55px; padding-top: 30px">
                    Contate-nos 
                </h1>
            </div>
        </div>
    </div>
</div>
<div class="container" >
    <div class="row" >
        <div class="col-md-8" style="margin-top: 50px">
            <div class="well well-sm">
                <form>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">
                                Nome</label>
                            <input type="text" class="form-control" id="name" placeholder="Seu Nome" required="required" />
                        </div>
                        <div class="form-group">
                            <label for="email">
                                Email</label>
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span>
                                </span>
                                <input type="email" class="form-control" id="email" placeholder="Seu email" required="required" /></div>
                        </div>
                        <div class="form-group">
                            <label for="subject">
                                Assunto</label>
                            <select id="subject" name="subject" class="form-control" required="required">
                                <option value="na" selected="">Escolha um:</option>
                                <option value="service">Serviços Gerais ao Consumidor</option>
                                <option value="suggestions">Sugestões</option>
                                <option value="reclamacao">Reclamações</option>
                                <option value="product">Suporte ao Produto</option>
                                
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">
                                Messagem</label>
                            <textarea name="message" id="message" class="form-control" rows="9" cols="25" required="required"
                                placeholder="Escreva aqui a sua messagem"></textarea>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary pull-right" id="btnContactUs">
                            Enviar Messagem</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
        <div class="col-md-4" style="margin-top: 50px">
            <form>
            <legend><span class="glyphicon glyphicon-globe"></span> Nosso Escritorio</legend>
            <address style="color: #FFFFFF">
                <strong>The Baggins, Corpotarion®.</strong><br>
                168 Tereza Ne
                São José dos Pinhais, BRL 83045290<br>
                <abbr title="Phone">
                    Phone:</abbr>
                +55(41) 99703-5516
            </address>
            <address style="color: #FFFFFF">
                <strong>The Baggins Corporation®</strong><br>
                <a href="mailto:#" style="color: #FFFFFF"><b>contato@thebaggins.com</b></a>
            </address>
            </form>
        </div>
    </div>
</div>

	             

	         </div> 
	      </div>
	    </div>
	 </section>	

</body>


</html>