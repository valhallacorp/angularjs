<!DOCTYPE html>
<html>

<head>

  <link rel="stylesheet" type="text/css" href="css/style.css"> 
  <link rel="stylesheet" type="text/css" href="css/style2.css">
  <link rel="stylesheet" type="text/css" href="css/menu.css">
  <meta charset="utf-8">
	<title>
		The Baggins
	</title>
</head>
<body>
	<style rel="stylesheet">
		body{
			background-image: url("./imagens/fusca4.jpg");
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: 100%;
		}
	</style>
	<div>
		<div class="topnav">
			<ul>
				<li class="icon">
	   				 <a href="javascript:void(0);" onclick="myFunction()">☰</a>
	  			</li>
				<li><a href="contato.php" target="_parent" title="">Contato</a></li>
				<li><a href="onde_estamos.php" target="_parent" title="">Onde Estamos</a></li>
				<li><a href="quem_somos.php" target="_parent" title="">Quem Somos</a></li>
				<div>
					<a href="index.php" target="_parent">
					<span class="span-logo">
					
					<img style="margin: 5px; margin-left: 1px" src="./imagens/home_w.png" >

					</span>
					</a>
				</div>
			</ul>
		</div>
		
		
	<section id="main">
	    <div>
	      	<div>
	         	<div class="signinup" style="position: fixed;">
	             
	             	<div id="lateral">
	             		
		             		<div>
		             			<h3 class="link-titulo">MENU DE ADMINISTRAÇÃO</h3>
		             		</div>
	             		
						<div id="menu">
							
						    <ul class="box">					
						        <li><a href="profile.php" target="_parent" >Perfil</a></li>
						        <li><a href="Search.php" target="_parent">Procurar Oportunidades</a></li>
						        <li ><a href="#">Cadastrar Oportunidades</a></li>
						        <li ><a href="#">Configurações</a></li>
						    </ul>

							
						    
						<!-- mais seções -->

							</div> <!-- /#menu -->
							</div id="link"> <!-- vazio --> <div>
							</div> <!-- /#lateral -->

					</div> 
				</div>
			</div>
	</section>	

	<div class="container" style="padding-top: 60px;">
  <h1 class="page-header" style="margin-left: 25%">Editar Perfil</h1>
  <div class="row">
    <!-- left column -->
    
    <!-- edit form column -->
    <div class="col-md-8 col-sm-6 col-xs-12 personal-info" style="margin-left: 100px">
      
      <h3 style="margin-left: 25%">Informações Pessoais</h3>
      <form class="form-horizontal" role="form">
        <div class="form-group">
          <label class="col-lg-3 control-label" style="font-size: 12px">Nome:</label>
          <div class="col-lg-8">
            <input class="form-control" placeholder="Nome" value="" type="text">
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label" style="font-size: 12px">Sobrenome:</label>
          <div class="col-lg-8">
            <input class="form-control" placeholder="Sobrenome" value="" type="text">
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label" style="font-size: 12px">Empresa:</label>
          <div class="col-lg-8">
            <input class="form-control" placeholder="www.suaempresa.com" value="" type="text">
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label" style="font-size: 12px">E-mail:</label>
          <div class="col-lg-8">
            <input class="form-control" placeholder="seuemail@seuemail.com" value="" type="text">
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label" style="font-size: 12px">Time Zone:</label>
          <div class="col-lg-8">
            <div class="ui-select">
              <select id="user_time_zone" class="form-control">
                <option value="Hawaii">(GMT-10:00) Hawaii</option>
                <option value="Alaska">(GMT-09:00) Alaska</option>
                <option value="Brazil">(GMT-03:00) Brasilia</option>
                <option value="Pacific Time (US & Canada)">(GMT-08:00) Pacific Time (US & Canada)</option>
                <option value="Arizona">(GMT-07:00) Arizona</option>
                <option value="Mountain Time (US & Canada)">(GMT-07:00) Mountain Time (US & Canada)</option>
                <option value="Central Time (US & Canada)" selected="selected">(GMT-06:00) Central Time (US & Canada)</option>
                <option value="Eastern Time (US & Canada)">(GMT-05:00) Eastern Time (US & Canada)</option>
                <option value="Indiana (East)">(GMT-05:00) Indiana (East)</option>
              </select>
            </div>
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label" style="font-size: 12px">Usuario:</label>
          <div class="col-md-8">
            <input class="form-control" placeholder="Usuario" value="" type="text">
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label" style="font-size: 12px">Senha:</label>
          <div class="col-md-8">
            <input class="form-control" placeholder="Senha" value="" type="password">
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label" style="font-size: 12px">Confirma senha:</label>
          <div class="col-md-8">
            <input class="form-control" placeholder="Senha" value="" type="password">
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label"></label>
          <div class="col-md-8">
            <input class="btn btn-primary" value="Salvar" type="button">
            <span></span>
            <input class="btn btn-default" value="Cancelar" type="reset">
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

</body>


</html>